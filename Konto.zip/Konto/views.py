# Konto

def konto_add(request):

    if request.method == 'POST':
        nameNr = request.POST.get('nameNr', None)
        print('Konto:', nameNr)
        eintrag = Save.objects.get(id=1)    # Referenz zur Datenbank (Der Zwischenspeicher ist statisch immer auf der 1)
        eintrag.nr_save = nameNr            
        eintrag.save()                      # Änderungen in Member-Datenbank speichern

    nameNr = Save.objects.get(id=1)        # Nummer aus DB holen (Der Zwischenspeicher ist statisch immer auf der 1)
    print('Load:', nameNr.nr_save)

    if nameNr.nr_save == 0:
        ActItems = Konto.objects.all()
    else:
        ActItems = Konto.objects.filter(nr = nameNr.nr_save) 
    
    # Summe der cashflow-Spalte berechnen
    summe_cashflow = ActItems.aggregate(Sum('cashflow'))['cashflow__sum']                  

    if summe_cashflow is not None:
        eintrag = Save.objects.get(id=1)    
        eintrag.sum_save = summe_cashflow            
        eintrag.save()    
        print("Die Summe der cashflow-Werte beträgt:", summe_cashflow)
    else:
        print("Es wurden keine Datensätze gefunden oder die cashflow-Spalte enthält NULL-Werte.")
        
    all_Saves = Save.objects.all()    
    return render(request, 'Koop_konto.html', {'all_items': ActItems, 'all_saves': all_Saves})

def konto_add2(request):

    if request.method == 'POST':
        Konto.objects.create(name = request.POST['itemName'], cashflow = request.POST['itemAmount'], nr = request.POST['itemNr'], comment = request.POST['itemComment'])
        printname = request.POST['itemName'] + '---' + request.POST['itemAmount'] + ' €' + '--- [' + request.POST['itemNr'] + ' ]' + ' [' + request.POST['itemComment'] + ' ]'
        print('Betrag hinzufügen:', printname)
    ActItems = Konto.objects.all()
    all_Saves = Save.objects.all()
    return render(request, 'Koop_konto.html', {'all_items': ActItems, 'all_saves': all_Saves})
