class Konto(models.Model):
    created_at = models.DateField(default=date.today)
    nr = models.IntegerField(default=0)
    name = models.CharField(max_length=200)
    cashflow = models.FloatField(default=0)
    comment = models.CharField(max_length=200)

    def __str__(self):
        return str(self.id) + ' - ' + str(self.created_at) + ' - ' + str(self.nr) + ' - ' + ' - ' + self.name + ' - ' + str(self.cashflow) + ' - ' + self.comment

class Save(models.Model):
    nr_save = models.IntegerField(default=0)
    sum_save = models.FloatField(default=0)

    def __str__(self):
        return str(self.id) + ' - ' + str(self.nr_save) + ' - ' + str(self.sum_save)
